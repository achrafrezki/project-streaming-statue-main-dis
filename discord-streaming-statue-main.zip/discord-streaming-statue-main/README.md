# 🎮 Discord Selfbot - Twitch Streaming Status

A simple Discord selfbot written in JavaScript that sets your status to "Streaming on Twitch" with a custom message and link.

> ⚠️ **DISCLAIMER**: Selfbots are against Discord’s Terms of Service. This project is for educational purposes only. Use it at your own risk.

## 🚀 Features

- ✅ Sets your status to **Streaming** with a custom message
- 🟣 Shows a Twitch-like purple "LIVE" badge on your profile
- 🧠 Very lightweight and easy to set up

## 📦 Requirements

- Node.js (v16+ recommended)
- A Discord **user token** (⚠️ NEVER share this)
- discord.js-selfbot-v13 v13 or up

## 📁 Installation

```bash
git clone https:https://github.com/b1lal4real/discord-streaming-statue
cd discord-streaming-statue
npm install

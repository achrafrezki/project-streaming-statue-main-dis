// index.js
const { Client } = require('discord.js-selfbot-v13');
const chalk = require('chalk');
require('dotenv').config();

const client = new Client({ checkUpdate: false });

client.once('ready', () => require('./events/ready')(client));

client.login(process.env.TOKEN);
